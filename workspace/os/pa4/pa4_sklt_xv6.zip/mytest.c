#include "types.h"
#include "user.h"
#include "stat.h"

int main()
{
	ls();
}
