package com.example.spinnerexample;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This class demos the Spinner View
 * Selecting an item from the Spinner will fire a onItemSelected event.
 * To handle the onItemSelected event, you must implement and register the OnItemSelectedListener.
 * This class includes 2 different ways of implementing and registering the OnItemSelectedListener.
 *
 * @author Lily Chang
 */
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    private Spinner spinner;
    private TextView tv;
    private String [] names = {"John Doe", "Jane doe", "Susan Brown"};
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println("onCreate");
        spinner = findViewById(R.id.spinner);
        adapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, names);
        spinner.setAdapter(adapter); //dynamically set the adapter that associates with the list of String.
        tv = findViewById(R.id.tv_item);
        /*
         *  Method 1. use an anonymous inner class to implement the OnItemSelectedListener and
         *            use setOnItemSelectedListener() method to register the listener.
         *  You use this method if you have more than one Spinner object and need to handle each
         *  ItemSelected event differently. That is, you need more than one event handler.
        */
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { //event handler below
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tv.setText(adapterView.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                tv.setText("");
            }
        });
        /**
         * Method 2. set the listener to this, which associates the event handler defined at the bottom.
         */
        //spinner.setOnItemSelectedListener(this);
    }

    //dummy onStart method
    protected void onStart() {
        super.onStart();
        System.out.println("onStart");
    }

    //dummy onPause method
    public void onPause() {
        super.onPause();
        System.out.println("onPause");
    }

    //dummy onResume method
    public void onResume() {
        super.onResume();
        System.out.println("onResume");
    }

    /*
     * Method 2. If you write implements AdapterView.OnItemSelectedListener in the class heading
     *           you will be enforced to implement the following methods.
     *           It is fine to leave the onNothingSelected empty without any code.
     */
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    //if you don't write anythoing, it'll not do anything.
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        //empty is fine
    }
}