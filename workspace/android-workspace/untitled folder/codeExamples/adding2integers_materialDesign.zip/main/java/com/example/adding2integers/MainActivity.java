package com.example.adding2integers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Demo an example similar to the one I had for JavaFX.
 * Create 2 TextView objects with TextInputLayout (part of material design), a button for performing
 * the addition, and a TextView for the sum of the 2 integers.
 */
public class MainActivity extends AppCompatActivity {
    private TextView int1, int2, result;
    private Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //use findViewById() to get the references of the View objects
        int1 = findViewById(R.id.num1);
        int2 = findViewById(R.id.num2);
        add = findViewById(R.id.addButton);
        result = findViewById(R.id.result);
    }

    /**
     * Event handler for the button click (onClick)
     *
     * @param view
     */
    public void addition(View view) {
        try {
            int sum = Integer.parseInt(int1.getText().toString()) +
                    Integer.parseInt(int2.getText().toString());
            result.setText(String.valueOf(sum));
        } catch (NumberFormatException exception) {
            Toast.makeText(this, "Must enter 2 integers!", Toast.LENGTH_LONG).show();
        }
    }
}