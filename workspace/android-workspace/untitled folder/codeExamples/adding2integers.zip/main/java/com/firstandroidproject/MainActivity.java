package com.firstandroidproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This app demonstrates an example similar to the one I had for JavaFX.
 * Create 2 EditText Views to allow the user enters 2 integers, 1 button for performing the addition,
 * and 1 TextView to show the sum of the 2 integers.
 */
public class MainActivity extends AppCompatActivity {
    private EditText et1, et2;
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //use findViewById() to get the references of the View objects.
        et1 = findViewById(R.id.et_num1);
        et2 = findViewById(R.id.et_num2);
        tv = findViewById(R.id.tv_sum);
    }

    /**
     * Event handler for the button click (onClick).
     * @param view the reference of the view object which fired the event.
     */
    public void add(View view) {
        try {
            int result = Integer.parseInt(et1.getText().toString())
                    + Integer.parseInt(et2.getText().toString());
            tv.setText(String.valueOf(result));
        } catch (NumberFormatException exception) {
            Toast.makeText(this, "Must Enter 2 Integers to add!", Toast.LENGTH_LONG).show();
        }
    }
}