package com.example.androidviews;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Demo the Android Views commonly used.
 * ImageView, ImageButton, Chips/ChipGroup, RadioButton/RadioGroup, CheckBox
 * See activity_main.xml for defining the attributes.
 * @author Lily Chang
 */
public class MainActivity extends AppCompatActivity {
    private ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image = findViewById(R.id.imageView);
    }

    /**
     * Button click handler to switch the image in the ImageView
     * @param view
     */
    public void showPizzatype(View view) {
        Toast.makeText(this, "Pizza!", Toast.LENGTH_SHORT).show();
        image.setImageResource(R.drawable.seafood); //change the image in the ImageView
    }
}