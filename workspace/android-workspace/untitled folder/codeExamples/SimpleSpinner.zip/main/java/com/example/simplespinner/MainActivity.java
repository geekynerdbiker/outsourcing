package com.example.simplespinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

/**
 * Demo the case when an Activity has only one Spinner.
 * Spinner is a dropdown which provides a list of objects for a single-select.
 * If the list in a Spinner is static, associate the list using the attribute name "entries".
 * If the list is from the backend, create an Adapter with the data source.
 * The listener for Spinner is AdapterView.OnItemSelectedListener, which include 2 abstract methods
 * you must implement.
 * @auther Lily Chang
 */
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Spinner spinner;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spinner);
        String[] fruits = {"apple", "orange", "strawberry"}; //could be a list from the backend
        adapter = new ArrayAdapter(
                this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, fruits);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this); //add the listener
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String fruit = spinner.getSelectedItem().toString(); //get the selected item
        Toast.makeText(this, fruit, Toast.LENGTH_SHORT).show(); //do something about the selected item
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        //it's fine to leave it blank
    }
}