#ifndef _PROJECTS_PROJECT1_node_H__
#define _PROJECTS_PROJECT1_node_H__

#include "projects/automated_warehouse/aw_message.h"
#include "projects/automated_warehouse/robot.h"

int find_path(Message* msg);

#endif