#ifndef __PROJECTS_PROJECT1_CROASSROADS_H__
#define __PROJECTS_PROJECT1_CROASSROADS_H__

#define CROSSROADS_UNIT_TIME_MS 1000 

int crossroads_step;

void run_crossroads(char **argv);

#endif /* __PROJECTS_PROJECT1_CROASSROADS_H__ */