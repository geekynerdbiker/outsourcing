#ifndef EX4_CPP_A_DUKE_H
#define EX4_CPP_A_DUKE_H
#include "Player.hpp"
class Duke{
    
public:
    void tax(Player& p);
    void block(Player& p);
};

#endif

