#ifndef EX4_CPP_A_CAPTIAN_H
#define EX4_CPP_A_CAPTIAN_H
#include "Player.hpp"

class Captain{
    
public:
    void steal(Player& p1, Player &p2);
    void block(Player& p1, Player &p2);
};

#endif
