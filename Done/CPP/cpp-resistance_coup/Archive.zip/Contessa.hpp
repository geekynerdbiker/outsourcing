#ifndef EX4_CPP_A_CONTESSA_H
#define EX4_CPP_A_CONTESSA_H
#include "Player.hpp"

class Contessa{
    
public:
    void block(Player& p1, Player& p2);
};

#endif
