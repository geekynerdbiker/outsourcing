#ifndef EX4_CPP_A_ASSASSIN_H
#define EX4_CPP_A_ASSASSIN_H
#include "Player.hpp"

class Assassin {
    
public:
    void coup(Player &p1, Player& p2);
};

#endif
