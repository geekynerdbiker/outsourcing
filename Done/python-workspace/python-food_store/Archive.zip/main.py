import os
from os import path

locations = ['북문', '쪽문', '정문', '동문']
location = input('식사할 위치를 선택하세요: ')

while location not in locations:
    print('잘못된 입력입니다. 식사 가능한 위치는 북문, 쪽문, 정문, 동문 중 한 곳 입니다.')
    location = input('식사할 위치를 선택하세요: ')

menus = ['일식', '양식', '한식', '중식']
menu = input('원하는 메뉴를 선택하세요: ')

while menu not in menus:
    print('잘못된 입력입니다. 선택 가능한 메뉴는 일식, 양식, 한식, 중식 중 하나 입니다.')
    location = input('원하는 메뉴를 선택하세요: ')

selection = '식당/' + location + '/' + menu

restaurants = []
restaurant_file_pathes = []
if path.exists(selection):
    for (root, directories, files) in os.walk(selection):
        for file in files:
            file_path = os.path.join(root, file)
            strings = os.path.splitext(file_path)[0].split('_')
            restaurants.append(strings[-1])
            restaurant_file_pathes.append(file_path)
else:
    print('해당 위치의 해당 메뉴의 식당이 존재하지 않습니다.')

restaurant = input('식당의 이름을 입력하세요: ')

while restaurant not in restaurants:
    print('해당 식당은 선택하신 위치와 메뉴의 식당 리스트 내에 존재하지 않습니다.')
    location = input('식당의 이름을 입력하세요: ')

index = 0
for rstr in restaurants:
    if rstr == restaurant:
        break
    else:
        index += 1

f = open(restaurant_file_pathes[index], 'r')

line = None
while line != ' ':
    line = f.readline()
    print(line)