package eventorganizer;

/**
 * Driver class
 *
 * @author Dongjin Kim
 */
public class RunProject1 {
    /**
     * run the program
     *
     * @param args command line
     */
    public static void main(String[] args) {
        new EventOrganizer().run();
    }
}

