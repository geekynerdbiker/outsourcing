package comp2402w22a4;

public class Main {

    public static void main(String[] args) {
        String[] input = {"/Users/jacoban/Documents/GitHub/Crebugs/Work/java/src/comp2402w22a4/a4-io/part4a.in"};

        Part4.main(input);
	// write your code here
    }
}
