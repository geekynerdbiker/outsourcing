//
//  tolower.c
//  c-workspace
//
//  Created by Jacob An on 2023/04/13.
//

#include <stdio.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    return tolower(argv[1][0]);
}
