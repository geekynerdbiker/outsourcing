계좌번호 -> login/atm.*
비밀번호 -> login/pin.*

로그인 성공 -> navigation/navigation.*

계좌정보 -> info/info.*

출금 -> withdraw/withdraw.*
출금확인 -> withdraw/withQuestion.*
출금성공 ->withdraw/checkWithdraw.*

입금 -> deposit/deposit.*
입금확인 -> deposit/depQuestion.*
입금성공 ->deposit/checkDeposit.*


송금 -> transfer/transfer.*
송금시 출금확인 -> transfer/withQuestion.*
송금확인 -> transfer/transQuestion.*
송금성공 ->transfer/checkTransfer.*
