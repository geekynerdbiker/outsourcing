#include <stdio.h>

int main(int argc, const char * argv[]) {
    printf("**********\n");
    printf("*        *\n");
    printf("* @    @ *\n");
    printf("*        *\n");
    printf("*   ll   *\n");
    printf("*        *\n");
    printf("*   --   *\n");
    printf("*        *\n");
    printf("**********\n");
    
    return 0;
}
