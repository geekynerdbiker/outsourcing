#include <stdio.h>

int main(int argc, const char * argv[]) {
    printf("%d은 정수입니다.\n", 37);
    printf("pi는 실수 %f입니다.\n", 3.14);
    printf("pi 실수를 소수점 2자리까지만 표시하면 %.2f입니다.\n", 3.14);
    printf("앏파벳 4번재 문자는 %c입니다.\n", 'D');
    printf("%s은 문자열입니다.\n", "Good Job!");
    
    return 0;
}
