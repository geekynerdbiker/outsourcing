/*
 파일명: myinfo2.c
 설명: 화면으로 문자열을 출력하는 프로그램
 작성자: 조찬익
 */

#include <stdio.h>

int main(int argc, const char * argv[]) {
    printf("2주차 과제를 제출합니다.\n");
    printf("이름 : 조찬익\n");
    printf("학번 : 2021620105\n");
    printf("학과 : 00대학교 00학과\n");
    printf("C 언어를 배우고 있습니다.");
    
    return 0;
}
