#include "SrcMain.h"

void ProcessCommandArgs(int argc, const char* argv[])
{
	// TODO: Implement
}
