#pragma once

void ProcessCommandArgs(int argc, const char* argv[]);
