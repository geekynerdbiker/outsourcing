// Main.cpp : Defines the entry point for the console application.
//

// DO NOT EDIT!!!!

#include "SrcMain.h"

int main(int argc, const char* argv[])
{
	ProcessCommandArgs(argc, argv);
	return 0;
}

