[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7647322&assignment_repo_type=AssignmentRepo)

TO DO:
* Upload main.c and other necessary files.
* Check test#.sh to see how to run your code input/output wise.
* Change Makefile accordingly.
  
**If you change any of the tests, you will automatically get 0.**
