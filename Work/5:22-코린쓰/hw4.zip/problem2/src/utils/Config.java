package utils;

public class Config {
    public final static int MAX_COINS_PER_MATCH = 15000;
    public final static int COIN_PER_USER = 20000;
    
    //public final static int QUEUED = -1;
}
