#include <string>

bool IsPalindrome(std::string s) {
    // TODO: problem 1.1

    return true;
}