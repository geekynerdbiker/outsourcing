
int HammingDistance(int x, int y) {
    // TODO: problem 1.2

    return 0;
}

