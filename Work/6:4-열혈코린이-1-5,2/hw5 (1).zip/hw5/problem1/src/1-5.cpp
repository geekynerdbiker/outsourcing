#include "header.h"

void Labeling(uint8_t* input_image, uint8_t* output_image, int width, int height){
    // TODO: problem 1.5
}