#include "header.h"

void MergeArrays(int* arr1, int len1, int* arr2, int len2) {
    // TODO: problem 1.3

}

