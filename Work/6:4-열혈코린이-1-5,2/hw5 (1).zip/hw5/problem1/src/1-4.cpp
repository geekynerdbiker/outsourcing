#include "header.h"

int* PascalTriangle(int N) {
    // TODO: problem 1.4

    return NULL;
}

