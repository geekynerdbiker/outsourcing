package design;

public enum Position { Manager, Supervisor, Salesperson; }
