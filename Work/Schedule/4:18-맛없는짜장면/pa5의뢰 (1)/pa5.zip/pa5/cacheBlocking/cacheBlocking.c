#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

/* Markers used to bound trace regions of interest */
volatile char MARKER_START, MARKER_END;

int main(int argc, char* argv[])
{

    /* Record marker addresses */
    FILE* marker_fp = fopen(".marker","w");
    assert(marker_fp);
    fprintf(marker_fp, "%llx\n%llx",
        (unsigned long long int) &MARKER_START,
        (unsigned long long int) &MARKER_END );
    fclose(marker_fp);

    if (argc!=3) {
        printf("Usage: ./cacheBlocking <matrix_a_file> <matrix_b_file>\n");
        exit(EXIT_FAILURE);
    }

    FILE* matrix_a_fp = fopen(argv[1], "r");
    if (!matrix_a_fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }
    size_t n;
    int ret = fscanf(matrix_a_fp, "%ld\n", &n);
    assert (ret==1);
    int* a = calloc( n*n, sizeof(int) );
    for ( size_t i=0; i<n; i++ ) {
        for ( size_t k=0; k<n; k++ ) {
            ret = fscanf(matrix_a_fp, "%d ", &a[i*n+k]);
            assert (ret==1);
        }
        ret = fscanf(matrix_a_fp, "\n");
    }
    fclose(matrix_a_fp);

    FILE* matrix_b_fp = fopen(argv[2], "r");
    if (!matrix_b_fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }
    size_t m;
    ret = fscanf(matrix_b_fp, "%ld\n", &m);
    assert (ret==1);
    assert( n==m );
    int* b = calloc( n*n, sizeof(int) );
    for ( size_t k=0; k<n; k++ ) {
        for ( size_t j=0; j<n; j++ ) {
            ret = fscanf(matrix_b_fp, "%d ", &b[k*n+j]);
            assert (ret==1);
        }
        ret = fscanf(matrix_b_fp, "\n");
    }
    fclose(matrix_b_fp);

    int* c = calloc( n*n, sizeof(int) );
    MARKER_START = 211;

    // int i;
    // int j;
    // int k;

    // int i1;
    // int j1;
    // int k1;
    int i, j ,k;
    int i1, j1, k1;
    // double sum;

    int B = 2;
    // int en = 2*(n/2);
    // for (i = 0; i < n; i++){
    //     for (j = 0; j < n; j++){
    //         c[i*n+j] = 0.0;        
    //     }
    // }

    // for (kk = 0; kk < en; kk += B) {
    //     for (jj = 0; jj < en; jj += B) {
    //         for (i1 = 0; i < n; i++) {
    //             for (j1 = jj; j < jj + B; j++) {
    //                 sum = c[i1*n+j1];
    //                 for (k = kk; k < kk + B; k++){
    //                     sum += a[i1*n+k]*b[k*n+j1];
    //                 }
    //                 c[i1*n+j1] = sum;
    //             }
    //         }
    //     }
    // }   
            

    // for(k=0; k < n; k+=B){
    //     for(i=0; i < n; i+=B){
    //         for(j=0; j < n; j+=B){
    //             for(k1=k; k1 < k+B; k1++){
    //                 for(i1=i; i1 < i+B; i1++){
    //                     for(j1=j; j1 < j+B; j1++){
    //                         c[i1*n+j1] += a[i1*n+k1] * b[k1*n+j1];
    //                     }
    //                 }
    //             }
    //         }
    //     }
    // }

    for(k=0; k < n; k+=B){
        for(i=0; i < n; i+=B){
            for(j=0; j < n; j+=B){
                for(i1=i; i1 < i+B; i1++){
                    for(j1=j; j1 < j+B; j1++){
                        for(k1=k; k1 < k+B; k1++){
                            c[i1*n+j1] += a[i1*n+k1] * b[k1*n+j1];
                        }
                    }
                }
            }
        }
    }
    MARKER_END = 211;    
    // kij
    // for ( size_t k=0; k<n; k++ ) {
    //     for ( size_t i=0; i<n; i++ ) {
    //         int r = a[i*n+k];
    //         for ( size_t j=0; j<n; j++ ) {
    //             c[i*n+j] += r * b[k*n+j];
    //         }
    //     }
    // }

    // ijk
    // for ( size_t i=0; i<n; i++ ) {
    //     for ( size_t j=0; j<n; j++ ) {
    //         int sum = c[i*n+j];
    //         for ( size_t k=0; k<n; k++ ) {
    //             sum += a[i*n+k] * b[k*n+j];
    //         }
    //         c[i*n+j] = sum;
    //     }
    // }

    // jki
    // for ( size_t j=0; j<n; j++ ) {
    //     for ( size_t k=0; k<n; k++ ) {
    //         int r = b[k*n+j];
    //         for ( size_t i=0; i<n; i++ ) {
    //             c[i*n+j] += a[i*n+k] * r;
    //         }
    //     }
    // }


    for ( size_t i=0; i<n; i++ ) {
        for ( size_t j=0; j<n; j++ ) {
            printf( "%d ", c[i*n+j] );
        }
        printf( "\n" );
    }

    free(c);
    free(b);
    free(a);
    exit(EXIT_SUCCESS);

}
