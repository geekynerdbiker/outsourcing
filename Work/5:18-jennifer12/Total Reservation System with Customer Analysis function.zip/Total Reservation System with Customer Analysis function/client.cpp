#include <iostream>
#include <string>
using namespace std;

class Client {
	string gender, name, pw;
	int ID, age, mileage;
	bool airplaneReserved, restaurantReserved, studyingroomReserved;
	bool newClient, reconnection;

public:
	Client();
	void setGender(string gender) { this->gender = gender; }
	void setName(string name) { this->name = name; }
	void pw(string pw) { this->pw = pw; }
	void setID(int ID) { this->ID = ID; }
	void setAge(int age) { this->age = age; }
	void setMileage(int mileage) { this->mileage = mileage; }
	void setAirplaneReserved(bool airplaneReserved) { this->airplaneReserved = airplaneReserved; }
	void setRestaurantReserved(bool restaurantReserved) { this->restaurantReserved = restaurantReserved; }
	void setStudyingroomReserved(bool studyingroomReserved) { this->studyingroomReserved = studyingroomReserved; }
	void setNewClient(bool newClient) { this->newClient = newClient; }
	void setReconnection(bool reconnection) { this->reconnection = reconnection; }
};

Client::Client() {
	this->ID = 0;
	this->age = 1;
	this->mileage = 0;
	this->airplaneReserved = 0;
	this->restaurantReserved = 0;
	this->studyingroomReserved = 0;
	this->newClient = 0;
	this->reconnection = 0;
}