package comp2402w22a4;

public class Main {

    public static void main(String[] args) {
        String[] input = {"3","/Users/jacoban/Documents/GitHub/Crebugs/Work/java/src/a4-io/part2a-use-x-3.in"};

        Part2.main(input);
	// write your code here
    }
}
